# website
smth i made to show how bad i am at web dev

also this aint a template i spent way longer than i should have on this
